import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/news.dart';
import '../services/news_service.dart';
import 'news_detail_page.dart';
import '../utils/custom_cache_manager.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({super.key});

  @override
  State<NewsPage> createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  int _currentPage = 1;
  int _lastPage = 1;
  bool _isLoading = true;
  bool _isSearching = false;
  String _searchQuery = "";

  final List<News> _articles = [];
  List<News> _filteredArticles = [];

  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _fetchArticles(page: 1);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _fetchArticles({int page = 1}) async {
    if (page == 1) {
      setState(() => _isLoading = true);
    }

    try {
      final result = await NewsService.fetchNews(page: page);
      final fetched = List<News>.from(result['articles'] as List<News>);

      setState(() {
        if (page == 1) {
          _articles
            ..clear()
            ..addAll(fetched);
        } else {
          _articles.addAll(fetched);
        }

        _filteredArticles = _searchQuery.isEmpty
            ? List<News>.from(_articles)
            : _articles
                  .where(
                    (a) =>
                        a.title.toLowerCase().contains(
                          _searchQuery.toLowerCase(),
                        ) ||
                        (a.content ?? "").toLowerCase().contains(
                          _searchQuery.toLowerCase(),
                        ),
                  )
                  .toList();

        _currentPage = result['currentPage'] as int;
        _lastPage = result['lastPage'] as int;
      });
    } catch (e) {
      debugPrint('Error fetching articles: $e');
    } finally {
      if (page == 1) setState(() => _isLoading = false);
    }
  }

  void _startSearch() {
    setState(() {
      _isSearching = true;
    });
  }

  void _stopSearch() {
    setState(() {
      _isSearching = false;
      _searchQuery = "";
      _filteredArticles = List<News>.from(_articles);
    });
  }

  void _filterArticles(String query) {
    setState(() {
      _searchQuery = query;
      _filteredArticles = _articles
          .where(
            (a) =>
                a.title.toLowerCase().contains(query.toLowerCase()) ||
                (a.content ?? "").toLowerCase().contains(query.toLowerCase()),
          )
          .toList();
    });
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1B5E20), Color(0xFF2E7D32)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      title: const Text('Saudi Football News'),
      actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: _startSearch),
      ],
    );
  }

  Widget _buildSearchBar() {
    if (!_isSearching) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: TextField(
        autofocus: true,
        decoration: InputDecoration(
          hintText: 'Search articles...',
          filled: true,
          fillColor: Colors.white,
          prefixIcon: const Icon(Icons.search),
          suffixIcon: IconButton(
            icon: const Icon(Icons.close),
            onPressed: _stopSearch,
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
        onChanged: _filterArticles,
      ),
    );
  }

  String _sourceFromLink(String? link) {
    if (link == null || link.isEmpty) return 'Source';
    try {
      final host = Uri.parse(link).host;
      if (host.isEmpty) return 'Source';
      return host.replaceFirst('www.', '');
    } catch (e) {
      return 'Source';
    }
  }

  Widget _articleCard(BuildContext context, News article) {
    final heroTag = article.image ?? article.title;
    final hasImage = article.image != null && article.image!.trim().isNotEmpty;
    final sourceText = _sourceFromLink(article.link);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: GestureDetector(
        onTap: () async {
          if (hasImage) {
            try {
              final provider = CachedNetworkImageProvider(
                article.image!,
                cacheManager: CustomCacheManager.instance,
              );
              await precacheImage(provider, context);
            } catch (_) {}
          }

          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => NewsDetailPage(article: article)),
          );
        },
        child: Card(
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            height: 120,
            child: Row(
              children: [
                Expanded(
                  flex: 4,
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: Hero(
                          tag: heroTag,
                          child: hasImage
                              ? CachedNetworkImage(
                                  imageUrl: article.image!,
                                  cacheManager: CustomCacheManager.instance,
                                  fit: BoxFit.cover,
                                  placeholder: (c, u) =>
                                      Container(color: Colors.grey[300]),
                                  errorWidget: (c, u, e) => Container(
                                    color: Colors.grey[300],
                                    child: const Icon(Icons.broken_image),
                                  ),
                                )
                              : Container(
                                  color: Colors.grey[300],
                                  child: const Icon(Icons.image_not_supported),
                                ),
                        ),
                      ),
                      // dark gradient overlay on image
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.black.withOpacity(0.35),
                              ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 6,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          article.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                        const Spacer(),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.green.shade50,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                sourceText,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.green.shade800,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "${article.publishedAt.toLocal()}".split(' ')[0],
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                            const Spacer(),
                            IconButton(
                              icon: const Icon(Icons.bookmark_border),
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Saved (demo)')),
                                );
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _onRefresh() async {
    await _fetchArticles(page: 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredArticles.isEmpty
                ? const Center(child: Text('No articles found'))
                : RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: ListView.builder(
                      key: const PageStorageKey('news_list'),
                      controller: _scrollController,
                      cacheExtent: 1200,
                      itemCount: _filteredArticles.length,
                      itemBuilder: (context, index) =>
                          _articleCard(context, _filteredArticles[index]),
                    ),
                  ),
          ),
          if (!_isSearching)
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.white,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.chevron_left),
                    onPressed: _currentPage > 1
                        ? () => _fetchArticles(page: _currentPage - 1)
                        : null,
                  ),
                  Text(
                    "$_currentPage / $_lastPage",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    icon: const Icon(Icons.chevron_right),
                    onPressed: _currentPage < _lastPage
                        ? () => _fetchArticles(page: _currentPage + 1)
                        : null,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
